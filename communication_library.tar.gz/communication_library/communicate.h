
void send_data(char mode ,void * msg);
char recieve_data(void * msg);

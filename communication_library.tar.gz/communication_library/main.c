
#include <util/delay.h>
#define FOSC 16000000 // Clock Speed
#define BAUD 9600
//#define MYUBRR ((FOSC/(BAUD*16))-1)
#define MYUBRR 103
#include "uart.h"

int main(){
	uart_init(MYUBRR);	
	DDRC = 0xFF;
	while(1){
			_delay_ms(1000);
			PORTC = 0xFF;
			put_c('a');
			_delay_ms(1000);
			PORTC = 0x00;
	
	}
	return 0;

}

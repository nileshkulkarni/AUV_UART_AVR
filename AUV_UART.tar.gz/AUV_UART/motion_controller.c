
#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include "uart.h"

#ifndef F_CPU
#define F_CPU 4000000UL
#endif

#define UART_BAUD_RATE 9600

void processData(int c){
		PORTC = c;

}
int main(void){
	
	DDRC = 0x00;	
		
	uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,F_CPU) );
	sei();
	unsigned int c;
	while(1){
		c = uart_getc();
		if(c & UART_NO_DATA){
				/*
			 	* NO UART DATA available
			 	*/
		}
		else{
				/*
				 *  New Data is avialable at the port.
				 *  check the frame for overrun errro
				 */
				if ( c & UART_FRAME_ERROR ){

	   					/* Framing Error detected, i.e no stop bit detected */
						uart_puts_P("UART Frame Error: ");
				}	
				if ( c & UART_OVERRUN_ERROR ){			
	
						/* 
						 *
						 * Overrun, a character already present in the UART UDR register was 
				 		 *
						 * not read by the interrupt handler before the next character arrived,
						 * one or more received characters have been dropped
				  		 *	
				 		 *                                                                  
						 */

						uart_puts_P("UART Overrun Error: ");
		
				}

				if ( c & UART_BUFFER_OVERFLOW ){

						/* 
						 *
					 	 * We are not reading the receive buffer fast enough,
						 *
						 * one or more received character have been dropped 
					 	 *
					 	 */

						uart_puts_P("Buffer overflow error: ");

				}

				processData(c);
			//	PORTC = c;
		}
	}
	return 0;
}
